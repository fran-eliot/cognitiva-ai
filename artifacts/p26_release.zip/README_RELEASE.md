# README — Paquete de Release (P26/P27)
[... pega aquí el bloque README_RELEASE.md de arriba si quieres editarlo a mano ...]
