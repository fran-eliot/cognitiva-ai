# HOW_TO_DEPLOY — CognitivaAI Intermodal (P26/P27)
[... pega aquí el bloque HOW_TO_DEPLOY.md de arriba si quieres editarlo a mano ...]
